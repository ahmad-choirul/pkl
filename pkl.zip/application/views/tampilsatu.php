<section class="content-header">
    <h1>
        Tampilan Pertama
        <small>Penjelasan nya Terserah</small>
    </h1>
</section>
<iframe width="100%" height=500px frameborder="0" src="Cchart"></iframe>
<!-- Main content -->
<section class="content">
<input style="width: 100px;height: 100px" type="image" src="https://www.r3.com/wp-content/uploads/2018/03/580b57fcd9996e24bc43c4fa.png" value="PLAY"  onclick="play()">
</section><!-- /.content -->	

<script>
	var audio = new Audio("assets//sound//alarm.mp3" ) ;
function play() {
       audio.play();
}
function stop() {
       audio.stop();
}

</script>

