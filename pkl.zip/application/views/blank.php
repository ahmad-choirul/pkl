<section class="content-header">
    <h1>
        Tampilan Pertama
        <small>penjelasan nya terserah</small>
    </h1>
</section>

<!-- Main content -->
<section class="content">

</section><!-- /.content -->
