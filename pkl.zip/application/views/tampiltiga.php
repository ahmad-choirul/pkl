<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        Tampilan Ketiga
        <small>penjelasan nya terserah</small>
    </h1>
</section>

<!-- Main content -->
<section class="content">
</section><!-- /.content -->
