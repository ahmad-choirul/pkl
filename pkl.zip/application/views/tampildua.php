<section class="content-header">
    <h1>
        Tampilan Kedua
        <small>penjelasan nya terserah</small>
    </h1>
</section>
<iframe width="100%" height="1000px" frameborder="0" src="https://www.detik.com/"></iframe>

<!-- Main content -->
<section class="content">

</section><!-- /.content -->