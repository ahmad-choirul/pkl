<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'Clogin';
$route['dashboard'] = 'Dashboard1';
$route['dashboardkedua'] = 'Dashboard2';
$route['tampilsatu'] = 'Ctampilsatu';
$route['tampildua'] = 'Ctampildua';
$route['tampiltiga'] = 'Ctampiltiga';
$route['ambildata'] = 'Cchart/ambildata';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
